import React, { useState } from "react";
import "./App.css";
import axios from "axios";

const App = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [results, setResults] = useState([]);

  const handleSearch = async () => {
    try {
      console.log("Search query:", searchQuery);

      // Make a GET request to the Spring Boot backend
      const response = await axios.get("http://localhost:9200/search", {
        params: { query: searchQuery }, // Sending the search query as a query parameter
      });

      // Update the results with the data received from the backend
      setResults(response.data);
    } catch (error) {
      console.error("Error fetching search results:", error);
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      // Make a POST request to the Spring Boot backend for file upload
      const response = await axios.post("http://localhost:9200/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      // Update the results based on the backend's response
      setResults([response.data]);
    } catch (error) {
      console.error("Error uploading file:", error);
    }
  };

  return (
    <div className="app">
      <header className="header">
        <h1>Find Your Song 🎵</h1>
        <p>Find your favorite songs by title, lyrics, or audio upload.</p>
      </header>
      <main className="main">
        <div className="search-container">
          <input
            type="text"
            className="search-bar"
            placeholder="Search by singer name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button className="search-button" onClick={handleSearch}>
            Search
          </button>
          <label htmlFor="file-upload" className="custom-file-upload">
            Upload Audio
          </label>
          <input
            id="file-upload"
            type="file"
            accept="audio/*"
            onChange={handleFileUpload}
          />
        </div>
        <div className="results-container">
          <h2>Search Results</h2>
          {results.length > 0 ? (
            <ul className="results-list">
              {results.map((result, index) => (
                <li key={index} className="result-item">
                  {result}
                </li>
              ))}
            </ul>
          ) : (
            <p>No results found.</p>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
