import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import App from "./App";

describe("App Component", () => {
  test("renders the header and initial UI elements", () => {
    render(<App />);
    
    // Check if header and description are rendered
    expect(screen.getByText(/Find Your Song🎵/i)).toBeInTheDocument();
    expect(screen.getByText(/Find your favorite songs by title, lyrics, or audio upload./i)).toBeInTheDocument();
    
    // Check if input and buttons are present
    expect(screen.getByPlaceholderText(/Search by title or lyrics.../i)).toBeInTheDocument();
    expect(screen.getByText(/Search/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Upload Audio/i)).toBeInTheDocument();
  });

  test("updates search query and triggers search", () => {
    render(<App />);
    
    const searchInput = screen.getByPlaceholderText(/Search by title or lyrics.../i);
    const searchButton = screen.getByText(/Search/i);

    // Simulate typing into the search input
    fireEvent.change(searchInput, { target: { value: "Song A" } });
    expect(searchInput.value).toBe("Song A");
    
    // Simulate clicking the search button
    fireEvent.click(searchButton);
    expect(screen.getByText("Song A")).toBeInTheDocument();
    expect(screen.getByText("Song B")).toBeInTheDocument();
    expect(screen.getByText("Song C")).toBeInTheDocument();
  });

  test("handles audio file upload and displays results", () => {
    render(<App />);
    
    const fileInput = screen.getByLabelText(/Upload Audio/i);

    // Mock a file upload
    const file = new File(["audio content"], "test-audio.mp3", { type: "audio/mpeg" });
    fireEvent.change(fileInput, { target: { files: [file] } });

    // Verify file upload handling results
    expect(screen.getByText("Uploaded Song X")).toBeInTheDocument();
    expect(screen.getByText("Uploaded Song Y")).toBeInTheDocument();
  });
});
