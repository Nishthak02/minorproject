const handleSearch = async () => {
    try {
      console.log("Search query:", searchQuery);
  
      // Make a GET request to your Spring Boot backend
      const response = await axios.get(`http://localhost:9200/search`, {
        params: { query: searchQuery }, // Send the search query as a query parameter
      });
  
      // Update the results with the data from the backend
      setResults(response.data);
    } catch (error) {
      console.error("Error fetching search results:", error);
    }
  };
  