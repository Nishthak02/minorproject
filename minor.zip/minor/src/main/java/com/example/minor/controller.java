package com.example.minor;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class controller {

    // API endpoint to handle song search
    @GetMapping("/api/search")
    public String searchSongs(@RequestParam String query) {
        // Replace with actual logic for querying Elasticsearch
        // For now, return mock data
        return "Search results for: " + query;
    }
}
